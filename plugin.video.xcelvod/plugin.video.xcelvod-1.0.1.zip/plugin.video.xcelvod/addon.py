from xbmcswift2 import Plugin
import urllib2
import urllib
from BeautifulSoup import BeautifulSoup
from cookielib import CookieJar

#-----------------------------------

plugin = Plugin()
cj = CookieJar() #CookieJar is used to save the Session ID and Member details provided back on login to the CDN.
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))

#-----------------------------------

CDNs = [{"base_url" : "http://alpha.sastatv.com/",
                    "login":"gurobox",
                    "password":"uhe923y8h2r",
                    "auth_url":"http://alpha.sastatv.com/sasta-remote/",
                    "label":"Indian Movies"},
        {"base_url" : "http://vod.g-box.ca/files/tvshows/",
                    "login":"gurobox",
                    "password":"uhe923y8h2r",
                    "auth_url":"http://vod.g-box.ca/remote/",
                    "label":"TV Shows"},
        {"base_url" : "http://movies.g-box.ca/files/movies/",
                    "login":"gurobox",
                    "password":"uhe923y8h2r",
                    "auth_url":"http://movies.g-box.ca/remote/",
                    "label":"English Movies"}
        ]

#--------------CDNS-----------------

def get_cookie_by_name(cj, name): #Function to help extract the cookie values for path to movie item.
    return [cookie for cookie in cj if cookie.name == name][0]

def get_folder_list(cdn, folder, full_path=""): #Main Function.
    global cj
    global opener
    #Refresh PHPSESSID token for every call, removed instability with requesting streams with an expired token.
    values = {'login': cdn['login'], 'pass': cdn['password']} #Login Details
    data = urllib.urlencode(values)
    opener.open(cdn['auth_url'], data) #Login - This fills the Cookie with the Session ID.
    directory_resp = opener.open(folder) #Open the folder.
    resp_data = directory_resp.read()
    cookie_phpsessid = get_cookie_by_name(cj, "PHPSESSID").value
    cookie_ammember = get_cookie_by_name(cj, "amember_remote_nr").value
    soup = BeautifulSoup(resp_data)
    folder_list = [] #Build the data for Kodi to display.
    for link in soup.findAll(href=True):
        if link['href'].endswith(('/')):#If the list item is a folder.
            if not "sasta-remote" in link['href'] and "leech" not in link['href'] and "speedtest" not in link['href'] and link['href'] != "/": #Some exclusions for presentation.
                plugin.log.error(str(folder+link['href']+'folder.jpg'+"|Cookie=PHPSESSID%3D"+cookie_phpsessid+"%3B%20amember_remote_nr%3D"+cookie_ammember))
                if not link['href'].startswith("/") and link['href'].endswith("/"): #Don't show the parent folder link
                    item = {
                        'label': urllib.unquote(link['href']).encode('utf8').strip('/'),
                        'path': plugin.url_for('list_folder', cdn=str(cdn), folder=folder+ link['href']),
                        'thumbnail': folder+link['href']+'folder.jpg'+"|Cookie=PHPSESSID%3D"+cookie_phpsessid+"%3B%20amember_remote_nr%3D"+cookie_ammember,
                        'is_playable': False,
                        'info':{'fanart_image':folder+link['href']+'fanart.jpg'+"|Cookie=PHPSESSID%3D"+cookie_phpsessid+"%3B%20amember_remote_nr%3D"+cookie_ammember},
                        'properties':{'fanart_image':folder+link['href']+'fanart.jpg'+"|Cookie=PHPSESSID%3D"+cookie_phpsessid+"%3B%20amember_remote_nr%3D"+cookie_ammember}

                    }
                    folder_list.append(item)
        elif link['href'].endswith(('.mp4','.avi', '.mkv')): #Media types Kodi can handle, no point showing ISO images in list.
            if "SastaTV" not in link['href']:

                item = {
                    'label': urllib.unquote(link['href']).decode('utf8'),
                    'path': folder+link['href']+"|Cookie=PHPSESSID%3D"+cookie_phpsessid+"%3B%20amember_remote_nr%3D"+cookie_ammember, #Kodi requires cookies to be set using the pipe | on the end of the URL.
                    'thumbnail': folder+link['href'].replace('.mp4', '').replace('.avi', '').replace('.mkv', '')+'-thumb.jpg'+"|Cookie=PHPSESSID%3D"+cookie_phpsessid+"%3B%20amember_remote_nr%3D"+cookie_ammember,
                    'properties':{'fanart':folder+link['href']+'fanart.jpg'+"|Cookie=PHPSESSID%3D"+cookie_phpsessid+"%3B%20amember_remote_nr%3D"+cookie_ammember},
                    'is_playable': True
                }
                folder_list.append(item)
    return folder_list #Return the list for Kodi to show.

#-----------------------------------

@plugin.route('/folder/<cdn>/<folder>/') #Open and list the speified folder.
def list_folder(folder, cdn):
    full_path = folder
    from ast import literal_eval
    cdn = literal_eval(cdn)
    folder_list = get_folder_list(cdn=cdn, folder=full_path, full_path=cdn['base_url']) #Run the main function, specifying the folder URL and that we are opening a list of files, not a list of folders.
    return folder_list

@plugin.route('/')
def index():
    items = []
    for a_CDN in CDNs:
        item = {
            'label': a_CDN['label'],
            'path': plugin.url_for('list_folder', cdn=str(a_CDN), folder=a_CDN['base_url']),
            'is_playable': False
        }
        items.append(item)

    #folder_list = get_folder_list() #Run the main function, opening the / root and only returning folders, not files.
    return items

if __name__ == '__main__':
    plugin.run()
