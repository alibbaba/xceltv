import urllib2
import urllib
import lxml.html

from cookielib import CookieJar
cj = CookieJar()
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))

directory_r esp = opener.open('http://alpha.sastatv.com/')
resp_data = directory_resp.read()

dom =  lxml.html.fromstring(resp_data)
for link in dom.xpath('//a/@href'): # select the url in href for all a tags(links)
    print link

values = {'login': 'gurobox', 'pass': 'uhe923y8h2r'}
data = urllib.urlencode(values)
response = opener.open("http://alpha.sastatv.com/sasta-remote/", data)

response2 = opener.open('http://alpha.sastatv.com/Malayalam/')
resp_data = response2.read()
dom =  lxml.html.fromstring(resp_data)
for link in dom.xpath('//a/@href'): # select the url in href for all a tags(links)
    print link

