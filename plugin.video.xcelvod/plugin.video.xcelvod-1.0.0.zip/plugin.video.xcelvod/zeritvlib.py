import xbmc, xbmcgui, xbmcplugin, traceback, time, re
import urllib2,urllib,cgi
import xbmcaddon
import base64,os
import sys
import xml.dom.minidom, base64
from xbmcaddon import Addon

__addon__       = xbmcaddon.Addon()
__addonname__   = __addon__.getAddonInfo('name')
__pluginid__ = Addon().getAddonInfo('id')
__settings__ = xbmcaddon.Addon(id=__pluginid__)
__plugin__ = __pluginid__.replace('plugin.video.', '')
__icon__        = __addon__.getAddonInfo('icon')
__rooturl__ = __settings__.getLocalizedString(40010)
__baseloginurl__ = __settings__.getLocalizedString(40001)
__libname__ = __settings__.getLocalizedString(40002)
__profilepath__ = xbmc.translatePath(__settings__.getAddonInfo('profile'))
__username__ = __settings__.getSetting('username')
__password__ = __settings__.getSetting('password')
__version__ = '1.0.3'
__skin__ = xbmc.getSkinDir()
__baseurl__ = __settings__.getLocalizedString(40000)

addon_id = Addon().getAddonInfo('id')
selfAddon = xbmcaddon.Addon(id=addon_id)
profile_path =  xbmc.translatePath(selfAddon.getAddonInfo('profile'))

PLUGIN_MODE_BUILD_DIR = 2
PLUGIN_MODE_PLAY_DIRECT_VIDEO = 10
PLUGIN_MODE_CLEARCOOKIE = 999
PLUGIN_MODE_INDIAN_MOVIES = 1000

def open_settings():
    __settings__.openSettings()

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]

    return param

def delete(filename):
    if os.path.isfile(filename):
        os.remove(filename)

def clearCookieCache():
    print 'Clearing cookie cache'
    delete(os.path.join(__profilepath__, __plugin__ + '.lwp'))
    delete(os.path.join(__profilepath__, __plugin__ + 'imovies.lwp'))
    delete(os.path.join(__profilepath__, __plugin__ + 'emovies.lwp'))
    delete(os.path.join(__profilepath__, __plugin__ + 'eshows.lwp'))
    xbmcgui.Dialog().ok(__settings__.getLocalizedString(30500), __settings__.getLocalizedString(30523).replace('\\n', '\n'))

def addDir(name,url,mode,iconimage,showContext=False,showLiveContext=False,isItFolder=True, linkType=None):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )

    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isItFolder)
    return ok

def getText(nodelist):
    rc = []
    for node in nodelist:
        if node.nodeType == node.TEXT_NODE:
            rc.append(node.data)
    return ''.join(rc)

def clean(name):
    list = [('&amp;', '&'),
            ('&quot;', '"'),
            ('<em>', ''),
            ('</em>', ''),
            ('&#39;', "'"),
            ('&#039;', "'"),
            ('&amp;#039;', "'")]
    for search, replace in list:
        name = name.replace(search, replace)

    return name.encode('utf-8', 'ignore')

def stripTags(data):
    lines = data.split('\n')
    myre = myre = re.compile('(^.*)<script.*>(.*)</script>(.*$)')
    newdata = ''
    for line in lines:
        result = myre.match(line)
        if result:
            newdata = newdata + result.group(1) + result.group(3) + '\n'
        elif '<end>' in line:
            newdata = newdata + line.replace('<end>', '') + '\n'
        else:
            newdata = newdata + line + '\n'

    return newdata

def readMemberPage(url):
    from t0mm0.common.net import Net
    net = Net()
    data = net.http_GET(url)

    if not isinstance(data, basestring):
        data = data.content

    return data

def getDataFromUrl(url):
    data = readMemberPage(url)
    
    return stripTags(data)

def getItemsFromUrl(url):
    data = getDataFromUrl(url)
    dom = xml.dom.minidom.parseString(stripTags(data))
    items = dom.getElementsByTagName('item')

    return items

def getItemFields(item):
    titleName = ''
    url = ''
    thumbnailUrl = ''
    modeNo = ''   

    title = item.getElementsByTagName("title")[0]
    titleName = title.firstChild.data
    link = item.getElementsByTagName("link")[0]
    url = link.firstChild.data        
    thumbnail = item.getElementsByTagName("media:thumbnail")[0]
    thumbnailUrl = thumbnail.getAttribute("url")
    mode = item.getElementsByTagName("mode")[0]
    modeNo = mode.firstChild.data

    return (titleName,
            url,
            thumbnailUrl,
            int(modeNo))

def build_show_directory(originalUrl):

    setting_playmode = int(__settings__.getSetting('playmode'))
    xbmc.log('playmode is: ' + str(setting_playmode))
    items = getItemsFromUrl(originalUrl)

    if items is None:
        print 'No items inside the link. Going back...'
        return
    else:
        itemCount = 0
        for item in items:
            title, url, thumb, mode = getItemFields(item)

            if url is not None and url != '':
                url = url.replace('amp;amp;', '&')
                url = url.replace('$server', __baseurl__)
                thumb = thumb.replace('$server', __baseurl__)

            addDir(title, url, mode, thumb)

def open_indian_movies(url, title):

    if base64.b64decode('aHR0cDovL2FscGhhLnNhc3RhdHYuY29t') in url:
        loginurl = base64.b64decode('aHR0cDovL2FscGhhLnNhc3RhdHYuY29tL3Nhc3RhLXJlbW90ZS8=')
        cookie_jar = os.path.join(__profilepath__, __plugin__ + 'imovies.lwp')
    elif base64.b64decode('aHR0cDovL21vdmllcy5nLWJveC5jYS8=') in url:
        loginurl = base64.b64decode('aHR0cDovL21vdmllcy5nLWJveC5jYS9yZW1vdGUv')
        cookie_jar = os.path.join(__profilepath__, __plugin__ + 'emovies.lwp')
    else:
        loginurl = base64.b64decode('aHR0cDovL3ZvZC5nLWJveC5jYS9yZW1vdGUv')
        cookie_jar = os.path.join(__profilepath__, __plugin__ + 'eshows.lwp')

    millis = str(int(round(time.time())))
    params = {'login': base64.b64decode('Z3Vyb2JveA=='),
              'pass': base64.b64decode('dWhlOTIzeThoMnI='),
              'login_attempt_id': millis,
              'amember_redirect_url': url}

    from t0mm0.common.net import Net
    net = Net()
    html = net.http_POST(loginurl, params)
    net.save_cookies(cookie_jar)

    with open(cookie_jar, 'r') as content_file:
        page = content_file.read()

    location = re.search('amember_remote_nr=(.+?);', page)

    if not location:
        location = 'CONTENTREMOVED'
    else:
        location = location.group(1)
        PlayVideoLink(title, url + '|Cookie=amember_remote_nr%3d' + location)

    return

def play_stream(url, name, ref = ''):
    if ref is not None and ref != '':
        print 'adding ref: ' + ref
        url = url + '|referer=' + ref

    listitem = xbmcgui.ListItem(label=str(name), iconImage='DefaultVideo.png', thumbnailImage=xbmc.getInfoImage('ListItem.Thumb'), path=url)
    print 'playing stream name: ' + str(name)
    listitem.setInfo(type='video', infoLabels={'Title': name, 'Path': url})
    xbmc.Player(xbmc.PLAYER_CORE_DVDPLAYER).play(str(url), listitem)
    return

def PlayVideoLink(showName, url):
    listitem = xbmcgui.ListItem(showName, iconImage='')
    listitem.setInfo("Video", {"Title":showName})
    listitem.setProperty('mimetype', 'video/x-msvideo')
    listitem.setProperty('IsPlayable', 'true')
    playlist = xbmc.PlayList(1)
    playlist.clear()
    playlist.add(url,listitem)
    xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
    xbmcPlayer.play(playlist)

    return        

def main():

    url = None
    origurl = None
    shareurl = None
    name = None
    thumb = None
    mode = None
    description = None
    guid = None
    ref = ''
    page = 0
    params = get_params()

    try:
        url = urllib.unquote_plus( params['url'] )
    except:
        pass
    try:
        origurl = urllib.unquote_plus( params['origurl'] )
    except:
        pass
    try:
        shareurl = urllib.unquote_plus( params['shareurl'] )
    except:
        pass
    try:
        thumb = urllib.unquote_plus( params['thumb'] )
    except:
        pass
    try:
        name = urllib.unquote_plus( params['name'] )
    except:
        pass
    try:
        guid = urllib.unquote_plus( params['guid'] )
    except:
        pass
    try:
        mode = int( params['mode'] )
    except:
        pass
    try:
        page = int( params['page'] )
    except:
        pass
    try:
        index = int( params['index'] )
    except:
        pass
    try:
        ref = urllib.unquote_plus( params['ref'] ) 
    except:
        pass

    print ("addon started with mode: " + str(mode))
    if os.path.isfile(os.path.join(__settings__.getAddonInfo('path'), __libname__ + '.py')):
        os.remove(os.path.join(__settings__.getAddonInfo('path'), __libname__ + '.py'))    

    try:
        if mode==None: 
            build_show_directory(__rooturl__)
        elif mode == PLUGIN_MODE_BUILD_DIR:
            build_show_directory(url)
        elif mode == PLUGIN_MODE_PLAY_DIRECT_VIDEO:
            PlayVideoLink(name, url)
        elif mode == PLUGIN_MODE_INDIAN_MOVIES:
            open_indian_movies(url, name)
        elif mode == PLUGIN_MODE_CLEARCOOKIE:
            clearCookieCache()
    except:
        traceback.print_exc(file=sys.stdout)

    if not (mode==PLUGIN_MODE_PLAY_DIRECT_VIDEO or mode==PLUGIN_MODE_INDIAN_MOVIES):
        xbmcplugin.endOfDirectory(int(sys.argv[1]))