import xbmcaddon, xbmcgui, os, urllib2, base64, time
from xbmcaddon import Addon

__pluginid__ = Addon().getAddonInfo('id')
__plugin__ = __pluginid__.replace('plugin.video.','')
__settings__ = xbmcaddon.Addon(id='plugin.video.' +  __plugin__)
__profilepath__ = xbmc.translatePath( __settings__.getAddonInfo('profile'))
__baseurl__ = __settings__.getLocalizedString(40000)
__baseloginurl__ = __settings__.getLocalizedString(40001)
__libname__ = __settings__.getLocalizedString(40002)
__rooturl__ = __settings__.getLocalizedString(40010)

#Start From Here

filename = __libname__ + ".py"

exec("import " + __libname__ + "\n"+ __libname__ + ".main()")